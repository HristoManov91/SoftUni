package com.example.laptop.model.entity;

public enum WarrantyType {
    BASIC , PREMIUM , LIFETIME
}
