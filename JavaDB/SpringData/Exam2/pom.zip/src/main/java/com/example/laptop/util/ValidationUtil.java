package com.example.laptop.util;

public interface ValidationUtil {

    <E> boolean isValid(E entity);
}
