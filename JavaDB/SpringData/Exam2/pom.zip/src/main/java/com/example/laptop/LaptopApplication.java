package com.example.laptop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaptopApplication {

    public static void main(String[] args) {
        SpringApplication.run(LaptopApplication.class, args);
    }

}
