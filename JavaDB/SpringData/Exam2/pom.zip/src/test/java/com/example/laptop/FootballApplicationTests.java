package com.example.laptop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FootballApplicationTests {

    @Test
    void contextLoads() {
    }

}
