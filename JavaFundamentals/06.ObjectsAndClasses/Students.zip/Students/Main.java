package Students;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Student> studentList = new ArrayList<>();

        String input = scanner.nextLine();
        while (!input.equals("end")) {
            String[] data = input.split("\\s+");
            String firstName = data[0];
            String lastName = data[1];
            int age = Integer.parseInt(data[2]);
            String hometown = data[3];

            if (isStudentExisting(studentList, firstName, lastName)) {
                for (Student student : studentList) {
                    if (student.getFirstName().equals(firstName) && student.getLastName().equals(lastName)) {
                        student.setAge(age);
                        student.setHometown(hometown);
                    }
                }
            } else {
                Student newStudent = new Student(firstName, lastName, age, hometown);
                studentList.add(newStudent);
            }
            input = scanner.nextLine();
        }
        String city = scanner.nextLine();
        for (Student student : studentList) {
            if (student.getHometown().equals(city)) {
                System.out.println(student.toString());
            }
        }
    }

    public static boolean isStudentExisting(List<Student> students, String firstName, String lastName) {
        for (Student student : students) {
            if (student.getFirstName().equals(firstName) && student.getLastName().equals(lastName)) {
                return true;
            }
        }
        return false;
    }
}