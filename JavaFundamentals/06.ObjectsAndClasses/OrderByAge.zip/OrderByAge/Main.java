package OrderByAge;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Person> personList = new ArrayList<>();
        String input = scanner.nextLine();
        while (!input.equals("End")){
            String[] personInfo = input.split("\\s+");
            String name = personInfo[0];
            String id = personInfo[1];
            int age = Integer.parseInt(personInfo[2]);

            Person person = new Person(name ,id , age);
            personList.add(person);

            input = scanner.nextLine();
        }
        personList
                .stream()
                .sorted((p1 , p2) -> Integer.compare(p1.getAge() , p2.getAge()))
                .forEach(p -> System.out.println(p.toString()));
    }
}
