package Articles;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int count = Integer.parseInt(scanner.nextLine());

        List<Articles> articlesList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String[] input = scanner.nextLine().split(", ");
            Articles articles = new Articles(input[0] , input[1] , input[2]);
            articlesList.add(articles);
        }
        String sortedCriteria = scanner.nextLine();
        articlesList
                .stream()
                .sorted((l , r) -> {
                    if (sortedCriteria.equals("title")){
                        return l.getTitle().compareTo(r.getTitle());
                    } else if (sortedCriteria.equals("content")){
                        return l.getContent().compareTo(r.getContent());
                    } else {
                        return l.getAuthor().compareTo(r.getAuthor());
                    }
                })
                .forEach(e -> System.out.println(e.toString()));
    }
}
