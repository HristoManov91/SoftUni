package StudentsExercise;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int countStudents = Integer.parseInt(scanner.nextLine());

        List<Students> studentsList = new ArrayList<>();
        for (int i = 0; i < countStudents; i++) {
            String[] studentsData = scanner.nextLine().split("\\s+");
            String firstName = studentsData[0];
            String lastName = studentsData[1];
            double grade = Double.parseDouble(studentsData[2]);

            Students students = new Students(firstName , lastName , grade);
            studentsList.add(students);
        }
        studentsList
                .stream()
                .sorted((s1 , s2) -> Double.compare(s2.getGrade() , s1.getGrade()))
                .forEach(s -> System.out.println(s.toString()));
    }
}
