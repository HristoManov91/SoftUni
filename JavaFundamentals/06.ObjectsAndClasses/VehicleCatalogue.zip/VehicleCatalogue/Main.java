package VehicleCatalogue;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        List<Truck> truckList = new ArrayList<>();
        List<Car> carList = new ArrayList<>();

        String input = scanner.nextLine();
        while (!input.equals("End")) {
            String[] vehicleData = input.split("\\s+");
            String typeVehicle = vehicleData[0];
            String model = vehicleData[1];
            String color = vehicleData[2];
            int horsepower = Integer.parseInt(vehicleData[3]);

            if (typeVehicle.equals("car")) {
                Car car = new Car( model, color, horsepower);
                carList.add(car);
            } else {
                Truck truck = new Truck( model, color, horsepower);
                truckList.add(truck);
            }
            input = scanner.nextLine();
        }
        String searchingInCatalogue = scanner.nextLine();
        while (!searchingInCatalogue.equals("Close the Catalogue")) {
            for (Car car : carList) {
                if (car.getModel().equals(searchingInCatalogue)) {
                    System.out.println(car);
                    break;
                }
            }
            for (Truck truck : truckList) {
                if (truck.getModel().equals(searchingInCatalogue)) {
                    System.out.println(truck);
                    break;
                }
            }
            searchingInCatalogue = scanner.nextLine();
        }
        if (carList.size() > 0) {
            System.out.printf("Cars have average horsepower of: %.2f.%n", carAverageHorsepower(carList));
        } else {
            System.out.println("Cars have average horsepower of: 0.00.");
        }
        if (truckList.size() > 0) {
            System.out.printf("Trucks have average horsepower of: %.2f.%n", truckHorsepower(truckList));
        } else {
            System.out.println("Trucks have average horsepower of: 0.00.");
        }

    }

    static double carAverageHorsepower(List<Car> carList) {
        int totalHorsepower = 0;
        for (Car car : carList) {
            totalHorsepower += car.getHorsepower();
        }
        return totalHorsepower * 1.0 / carList.size();
    }

    static double truckHorsepower(List<Truck> truckList) {
        int totalHorsepower = 0;
        for (Truck truck : truckList) {
            totalHorsepower += truck.getHorsepower();
        }
        return totalHorsepower * 1.0 / truckList.size();
    }
}
