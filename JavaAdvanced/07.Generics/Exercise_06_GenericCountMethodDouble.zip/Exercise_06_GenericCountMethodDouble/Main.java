package Exercise_06_GenericCountMethodDouble;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int count = Integer.parseInt(scanner.nextLine());

        Box<Double> list = new Box<>();
        for (int i = 0; i < count; i++) {
            list.addElement(Double.parseDouble(scanner.nextLine()));
        }
        double elementToCompare = Double.parseDouble(scanner.nextLine());
        System.out.println(list.countBiggerElement(elementToCompare));
    }
}
