package Exercise_05_GenericCountMethodStrings;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int count = Integer.parseInt(scanner.nextLine());

        Box<String> list = new Box<>();
        for (int i = 0; i < count; i++) {
            list.addElement(scanner.nextLine());
        }
        String elementToCompare = scanner.nextLine();
        System.out.println(list.countBiggerElement(elementToCompare));
    }
}
