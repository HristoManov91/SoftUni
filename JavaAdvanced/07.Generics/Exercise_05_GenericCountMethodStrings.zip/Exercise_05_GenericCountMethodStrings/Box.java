package Exercise_05_GenericCountMethodStrings;

import java.util.ArrayList;
import java.util.List;

public class Box<T extends Comparable<T>> {
    private List<T> list;

    public Box(){
        this.list = new ArrayList<>();
    }

    public void addElement(T element){
        this.list.add(element);
    }

    public int countBiggerElement (T element){
        int count = 0;
        for (T item : list) {
            if (item.compareTo(element) > 0){
                count++;
            }
        }
        return count;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (T value : list) {
            sb.append(value.getClass().getName()).append(": ").append(value);
            sb.append(System.lineSeparator());
        }
        return sb.toString();
    }
}
