package Exercise_04_GenericSwapMethodInteger;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int count = Integer.parseInt(scanner.nextLine());

        Box<Integer> list = new Box<>();
        for (int i = 0; i < count; i++) {
            list.addElement(Integer.parseInt(scanner.nextLine()));
        }
        int[] indexToSwap = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        list.swapElements(indexToSwap[0] , indexToSwap[1]);
        System.out.println(list.toString());
    }
}
