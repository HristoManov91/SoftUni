package Exercise_03_GenericSwapMethodString;

import java.util.ArrayList;
import java.util.List;

public class Box<T> {
    private List<T> list;

    public Box(){
        this.list = new ArrayList<>();
    }

    public void addElement(T element){
        this.list.add(element);
    }

    public void swapElements(int firstIndex, int secondIndex) {
        T elementFromFirstIndex = list.get(firstIndex);
        list.set(firstIndex , list.get(secondIndex));
        list.set(secondIndex , elementFromFirstIndex);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (T value : list) {
            sb.append(value.getClass().getName()).append(": ").append(value);
            sb.append(System.lineSeparator());
        }
        return sb.toString();
    }
}
