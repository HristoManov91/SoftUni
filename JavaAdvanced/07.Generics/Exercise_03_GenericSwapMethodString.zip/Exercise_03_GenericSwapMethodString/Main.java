package Exercise_03_GenericSwapMethodString;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int count = Integer.parseInt(scanner.nextLine());

        Box<String> list = new Box<>();
        for (int i = 0; i < count; i++) {
            list.addElement(scanner.nextLine());
        }
        int[] indexToSwap = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
        list.swapElements(indexToSwap[0] , indexToSwap[1]);
        System.out.println(list.toString());
    }
}
