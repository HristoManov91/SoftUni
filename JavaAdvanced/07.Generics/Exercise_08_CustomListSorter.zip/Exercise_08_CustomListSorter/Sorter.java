package Exercise_08_CustomListSorter;

public class Sorter<T extends Comparable<T>> {

    public static <T extends Comparable<T>> void sort (CustomList<String> customList){
        for (int i = 0; i < customList.size(); i++) {
            String element = customList.get(i);
            for (int j = i + 1; j < customList.size(); j++) {
                String nextElement = customList.get(j);
                if (element.compareTo(nextElement) > 0){
                    customList.swap(i , j);
                }
            }
        }
    }
}
