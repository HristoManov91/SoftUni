package Exercise_08_CustomListSorter;

import java.util.ArrayList;
import java.util.List;

public class CustomList<T extends Comparable<T>> {
    private List<T> list;

    public CustomList() {
        this.list = new ArrayList<>();
    }

    public void add(T element) {
        this.list.add(element);
    }

    public T remove(int index) {
        if (validIndex(index)) {
            return list.remove(index);
        }
        throw new IndexOutOfBoundsException("Index " + index + " is out of bounds");
    }

    public boolean contains(T element) {
        return list.contains(element);
    }

    public void swap(int firstIndex, int secondIndex) {
        if (validIndex(firstIndex) && validIndex(secondIndex)) {
            T element = list.get(firstIndex);
            list.set(firstIndex, list.get(secondIndex));
            list.set(secondIndex, element);
        } else {
            throw new IndexOutOfBoundsException("Indexes " + firstIndex + " or " + secondIndex + " is out of bounds");
        }
    }

    public int countGreaterThan(T element) {
        long count = list.stream().filter(n -> n.compareTo(element) > 0).count();
        return (int) count;
    }

    public T getMin() {
        return (T) list.stream().min(Comparable::compareTo).get();
    }

    public T getMax() {
        return list.stream().max(Comparable::compareTo).get();
    }

    public void print() {
        if (this.list.isEmpty()) {
            throw new IllegalStateException("Empty list");
        } else {
            StringBuilder sb = new StringBuilder();
            for (T item : list) {
                sb.append(item).append(System.lineSeparator());
            }
            System.out.println(sb.toString());
        }
    }

    private boolean validIndex(int index) {
        return index >= 0 && index < this.list.size();
    }

    public int size() {
        return this.list.size();
    }

    public T get(int index) {
        return list.get(index);
    }
}
