package Lab_03_BankAccount;

public class BankAccount {
    private static int currentId = 1;
    private static double interestRate = 0.02;

    private int id;
    private double balanced;
    private double interest;

    public BankAccount(){
        this.id = currentId++;
        this.interest = interestRate;
    }
    public static void setInterestRate(double interest) {
        BankAccount.interestRate = interest;
    }

    public double getInterest(int years) {
        return interestRate * balanced * years;
    }

    public void deposit (double amount){
        this.balanced += amount;
    }

    public int getId() {
        return this.id;
    }
}
