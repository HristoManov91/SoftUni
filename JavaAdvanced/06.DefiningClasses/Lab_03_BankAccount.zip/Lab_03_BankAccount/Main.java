package Lab_03_BankAccount;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<BankAccount> bankAccountList = new ArrayList<>();
        String input = scanner.nextLine();
        while (!input.equals("End")){
            String[] tokens = input.split(" ");
            String command = tokens[0];
            switch (command){
                case "Create":
                    BankAccount bankAccount = new BankAccount();
                    bankAccountList.add(bankAccount);
                    System.out.printf("Account ID%d created%n", bankAccount.getId());
                    break;
                case "Deposit":
                    int id = Integer.parseInt(tokens[1]);
                    if (id > bankAccountList.size()){
                        System.out.println("Account does not exist");
                        break;
                    }
                    double amount = Double.parseDouble(tokens[2]);
                    bankAccountList.get(id - 1).deposit(amount);
                    System.out.printf("Deposited %.0f to ID%d%n", amount , id);
                    break;
                case "GetInterest":
                    int ID = Integer.parseInt(tokens[1]);
                    if (ID > bankAccountList.size()){
                        System.out.println("Account does not exist");
                        break;
                    }
                    int years = Integer.parseInt(tokens[2]);
                    System.out.printf("%.2f%n" , bankAccountList.get(ID - 1).getInterest(years));
                    break;
                case "SetInterest":
                    double rate = Double.parseDouble(tokens[1]);
                    BankAccount.setInterestRate(rate);
                    break;
            }

            input = scanner.nextLine();
        }
    }
}
