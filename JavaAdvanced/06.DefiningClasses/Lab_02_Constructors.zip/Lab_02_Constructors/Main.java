package Lab_01_CarInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int countCars = Integer.parseInt(scanner.nextLine());

        List<Car> carList = new ArrayList<>();
        for (int i = 0; i < countCars; i++) {
            String[] tokens = scanner.nextLine().split(" ");
            Car car;
            if (tokens.length == 3){
                car = new Car(tokens[0] , tokens[1] , Integer.parseInt(tokens[2]));
            } else {
                car = new Car(tokens[0]);
            }
            carList.add(car);
        }

        carList.forEach(c -> System.out.println(c.toString()));
    }
}
