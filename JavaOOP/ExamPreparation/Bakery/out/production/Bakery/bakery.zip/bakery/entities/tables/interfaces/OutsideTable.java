package bakery.entities.tables.interfaces;

public class OutsideTable extends BaseTable{
    public OutsideTable(int tableNumber, int capacity) {
        super(tableNumber, capacity, 3.50);
    }
}
