package bakery.entities.tables.interfaces;

public class InsideTable extends BaseTable{
    public InsideTable(int tableNumber, int capacity) {
        super(tableNumber, capacity, 2.50);
    }
}
