package aquarium.entities.decorations;

public class Ornament extends BaseDecoration{
    public Ornament() {
        super(1, 5);
    }
}
